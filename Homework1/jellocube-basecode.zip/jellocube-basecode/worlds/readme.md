These are some example virtual worlds.

You can create your own by opening the xml file in sublime or notepad++, any editor
and changing the values.

